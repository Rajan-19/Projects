package com.example.loginpage;

import android.location.Location;

public class cLocation extends Location {

    public cLocation(String provider) {
        super(provider);
    }

    public void setbUseMetricUnits(boolean bUseMetricUnits) {
    }
}
