package com.example.loginpage;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class Running extends AppCompatActivity {
    private static final long START_TIME_IN_MILLIS = 600000;

    private TextView timertext;
    private Button start;

    private CountDownTimer timer;//mcountdowntimer

    private boolean mTimerRunning;
    private long mTimeLeftInMillis = START_TIME_IN_MILLIS;

//    Timer timer;
//    TimerTask timertask;
//    Double time = 0.0;
//
//    boolean timerstarted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_running);

        timertext = findViewById(R.id.timer);
        //mtextviewcountdown
        TextView speed = findViewById(R.id.speed);
        start = findViewById(R.id.start);
        //mbuttonstart mbuttonreset
        Button reset = findViewById(R.id.reset);

//        timer = new Timer();

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                if (timerstarted == false){
//                    timerstarted = true;
//                    start.setText("stop");
////                    start.setTextColor(ContextCompat.getColor(this, R.color.red));
//                }else{
//                    timerstarted = false;
//                    start.setText("start");
//                }
//                startTimer();
                if(mTimerRunning){
                    pauseTimer();
                }else{
                    startTimer();
                }
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetTimer();
            }
        });

        updateCountdownText();
    }
    @SuppressLint("SetTextI18n")
    private void pauseTimer() {
        timer.cancel();
        mTimerRunning = false;
        start.setText("pause");
    }
    @SuppressLint("SetTextI18n")
    private void startTimer() {
        timer = new CountDownTimer(mTimeLeftInMillis, 1000) {
            @Override
            public void onTick(long l) {
                mTimeLeftInMillis = l;
                updateCountdownText();
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFinish() {
                mTimerRunning = false;
                start.setText("start");
            }
        }.start();

        mTimerRunning = true;
        start.setText("pause");
    }
    private void resetTimer() {
        mTimeLeftInMillis = START_TIME_IN_MILLIS;
//        start.setText("start");
        updateCountdownText();
    }
    private void updateCountdownText() {
        int minutes = (int) (mTimeLeftInMillis/ 1000) / 60;
        int seconds = (int) (mTimeLeftInMillis/ 1000) % 60;

        String timeLeftFormatted = String.format(Locale.getDefault(),"%02d : %02d", minutes, seconds);
        timertext.setText(timeLeftFormatted);
    }
}